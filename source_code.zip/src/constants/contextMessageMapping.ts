export const CONTEXT_MESSAGE = {
  GREETING: "Welcome to Adaca.",
  END: "Thank you, see you around.",
  NO_CONTEXT: `Sorry, I don't understand.`,
};
